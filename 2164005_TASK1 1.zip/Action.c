Action()
{
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
	
	lr_start_transaction("1_launch");

	web_reg_find("Search=Body",
		"SaveCount=count1",
		"Text=Hospital management System",
		LAST);

	web_url("hospital", 
		"URL=http://localhost/hospital/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=assets/images/why.jpg", "Referer=http://localhost/hospital/assets/css/style.css", ENDITEM, 
		"Url=assets/fonts/PT_Sans-Web-Regular.ttf", "Referer=http://localhost/hospital/assets/css/style.css", ENDITEM, 
		"Url=assets/webfonts/fa-solid-900.woff2", "Referer=http://localhost/hospital/assets/css/fontawsom-all.min.css", ENDITEM, 
		"Url=assets/fonts/PT_Sans-Web-Bold.ttf", "Referer=http://localhost/hospital/assets/css/style.css", ENDITEM, 
		"Url=assets/webfonts/fa-brands-400.woff2", "Referer=http://localhost/hospital/assets/css/fontawsom-all.min.css", ENDITEM, 
		"Url=assets/webfonts/fa-regular-400.woff2", "Referer=http://localhost/hospital/assets/css/fontawsom-all.min.css", ENDITEM, 
		LAST);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=126", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
	if(atoi(lr_eval_string("{count1}"))==0)
	{
		lr_error_message("Text not found");
	}
	
	lr_end_transaction("1_launch",LR_AUTO);

	lr_think_time(39);

	lr_start_transaction("2_Book_appoinment");

	web_reg_find("Search=Body",
		"SaveCount=count2",
		"Text=User-Login",
		LAST);

	web_url("user-login.php", 
		"URL=http://localhost/hospital/hms/user-login.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/hospital/", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=vendor/fontawesome/fonts/fontawesome-webfont.woff2?v=4.3.0", "Referer=http://localhost/hospital/hms/vendor/fontawesome/css/font-awesome.min.css", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/raleway/v34/1Ptug8zYS_SKggPNyC0ITw.woff2", "Referer=http://fonts.googleapis.com/", ENDITEM, 
		"Url=http://fonts.gstatic.com/s/lato/v24/S6uyw4BMUTPHjx4wXg.woff2", "Referer=http://fonts.googleapis.com/", ENDITEM, 
		"Url=/favicon.ico", ENDITEM, 
		LAST);

	web_set_sockets_option("TLS_SNI", "0");
	
	if(atoi(lr_eval_string("{count2}"))==0)
	{
		lr_error_message("Text not found");
	}

	lr_end_transaction("2_Book_appoinment",LR_AUTO);

	lr_think_time(18);

	/*web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=14:8lgGC6wjihxxK-MfWOr6KeRrPSPMlp4DXD0KG47B5so&cup2hreq=c80c0432c814c0da813bca2ab53ef44deceb8dbff228c70808f493a33b4117c4", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chrome\",\"acceptformat\":\"crx3,puff\",\"app\":[{\"appid\":\"niikhdgajlphfehepabhhblakbdgeefj\",\"brand\":\"CHBF\",\"cohort\":\"1:1uh3:\",\"cohortname\":\"Auto Main Cohort.\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.7e329996ac41ced208e9d13f023bb152b55bd2c4d158f9482a7dd65d6eb1b03b\"}]},\"ping\":{\"ping_freshness\":\"{8eb55810-3810-4831-a1a3-825560c95425}\",\"rd\":6399},\"updatecheck\":{},\""
		"version\":\"2024.6.28.0\"},{\"appid\":\"ihnlcenocehgdaegdmhbidjhnhdchfmm\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{a4e08fb9-5bf7-49e2-852a-70247ab0a525}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"0.0.0.0\"},{\"appid\":\"neifaoindggfcjicffkgpmnlppeffabd\",\"brand\":\"CHBF\",\"cohort\":\"1:1299:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\""
		"fp\":\"1.c900ba9a2d8318263fd43782ee6fd5fb50bad78bf0eb2c972b5922c458af45ed\"}]},\"ping\":{\"ping_freshness\":\"{d1ddadff-63d9-433a-9a0e-8f1b42ca735a}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"1.0.2738.0\"},{\"appid\":\"oimompecagnajdejgnnjijobebaeigek\",\"brand\":\"CHBF\",\"cohort\":\"1:1zdx:\",\"cohortname\":\"4.10.2710.0 to Windows (x86/x64)\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{7c1e9250-bd9a-4bdd-a608-164376a6742e}\",\"rd\":6399},\""
		"updatecheck\":{},\"version\":\"4.10.2710.0\"},{\"appid\":\"gcmjkmgdlgnkkcocmoeiminaijmmjnii\",\"brand\":\"CHBF\",\"cohort\":\"1:bm1:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.cd1978742a4afdbaaa15bf712d5c90bef4144caa99024df98f6a9ad58043ae85\"}]},\"ping\":{\"ping_freshness\":\"{31d0b3b1-939f-4f2c-994f-7dd552ae0930}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"9.49.1\"},{\"accept_locale\":\"ENUS500000\",\"appid\":\""
		"obedbbhbpmojnkanicioggnmelmoomoc\",\"brand\":\"CHBF\",\"cohort\":\"1:s6f/2hjl:2hjr@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.62a1b9baf65df488bbe7efcaab28f422d42aa3965d28948f79b627fd500cc5a2\"}]},\"ping\":{\"ping_freshness\":\"{fb1f193b-c368-47b8-ae4b-4635a78c94d3}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"20240622.646249836.14\"},{\"appid\":\"lmelglejhemejginpboagddgdfbepgmp\",\"brand\":\"CHBF\",\"cohort\""
		":\"1:lwl:2hmr@0.025\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.b03b0ca7b4de187189db6ea26833031c03d40402c0258e3b264e61650430a9e0\"}]},\"ping\":{\"ping_freshness\":\"{16046d49-c58c-4186-a842-137eb0a0bb22}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"455\"},{\"appid\":\"kiabhabjdbkjdpjbpigfodbdjmbglcoo\",\"brand\":\"CHBF\",\"cohort\":\"1:v3l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\""
		"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.f6cc30e6a2d15e778f6701074d1f4b4505db1f516e06c9969160e0d6c62c5837\"}]},\"ping\":{\"ping_freshness\":\"{167c8150-d3d4-4474-81d9-7e4f6ee54764}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"2024.6.30.1\"},{\"appid\":\"giekcmmlnklenlaomppkphknjmnnpneh\",\"brand\":\"CHBF\",\"cohort\":\"1:j5l:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.3eb16d6c28b502ac4cfee8f4a148df05f4d93229fa36a71db8b08d06329ff18a\"}]},\"ping\":{\"ping_freshness\":\"{151823a7-4292-4fbb-8de9-6e15960a2d0b}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"7\"},{\"appid\":\"khaoiebndkojlmppeemjhbpbandiljpe\",\"brand\":\"CHBF\",\"cohort\":\"1:cux:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.8aed26106d9b12205a9cc12ca05a8e0c347d405a5db4b77f28b3324ead0bbae4\"}]},\"ping\":{\"ping_freshness\""
		":\"{48805398-d3d8-468b-9f1d-dd955853ecb6}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"66\"},{\"appid\":\"hfnkpimlhhgieaddgfemjhofmfblmnib\",\"brand\":\"CHBF\",\"cohort\":\"1:287f:\",\"cohortname\":\"Auto full\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.23687b1f6088465f4c70846912e630aa2d924c3b9b586cd47ab3b3d77e671354\"}]},\"ping\":{\"ping_freshness\":\"{4d3d8d14-32e9-4057-b855-ed3b252384c7}\",\"rd\":6399},\"updatecheck\":{},\"version\":\""
		"8918\"},{\"appid\":\"llkgjffcdpffmhiakmfcdcblohccpfmo\",\"brand\":\"CHBF\",\"cohort\":\"1::\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.50194698c958b2db374ace82588897597f893533a46f0243bd0e972a7b7ce2a5\"}]},\"ping\":{\"ping_freshness\":\"{81259553-9653-432a-95ba-c800c1ee331f}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"1.0.0.16\"},{\"appid\":\"laoigpblnllgcgjnjnllmfolckpjlhki\",\"brand\":\"CHBF\",\"cohort\":\"1:10zr:\",\"cohortname\":\"Auto"
		"\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"ping\":{\"ping_freshness\":\"{48387025-db77-458c-9427-e75782e5ba1b}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"1.0.7.1652906823\"},{\"appid\":\"ehgidpndbllacpjalkiimkbadgjfnnmc\",\"brand\":\"CHBF\",\"cohort\":\"1:ofl:\",\"cohortname\":\"stable64\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.a8a79d350c2a5e3bc36226633a8e0bed0dfab184e77f38fc8f0820ebacf8eafc\"}]},\"ping\":{\""
		"ping_freshness\":\"{73e6dc34-ea51-4015-9143-850a57127784}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"2018.8.8.0\"},{\"appid\":\"efniojlnjndmcbiieegkicadnoecjjef\",\"brand\":\"CHBF\",\"cohort\":\"1:18ql:\",\"cohortname\":\"Auto Stage3\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.900410b03a2b6d9b98abb85833bbb2a557cbda8fe7df65fb688a9ca04a3f6d40\"}]},\"ping\":{\"ping_freshness\":\"{603043b4-2c00-42d5-bce3-e851853bfcb5}\",\"rd\":6399},\""
		"updatecheck\":{},\"version\":\"1009\"},{\"appid\":\"jflookgnkcckhobaglndicnbbgbonegd\",\"brand\":\"CHBF\",\"cohort\":\"1:s7x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.2e871143703b862fcdf558b45cfe02a93a2cb74518b30f4c1e0f07753b0823b8\"}]},\"ping\":{\"ping_freshness\":\"{917b3d40-ffd1-46cf-aacd-3756af5c2114}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"3033\"},{\"appid\":\"jamhcnnkihinmdlkakkaopbjbbcngflc\",\"brand\""
		":\"CHBF\",\"cohort\":\"1:wvr:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.c52c62a7c50daf7d3f73ec16977cd4b0ea401710807d5dbe3850941dd1b73a70\"}]},\"ping\":{\"ping_freshness\":\"{052d388b-ee1b-4e7e-b59c-5d1e620554ed}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"120.0.6050.0\"},{\"appid\":\"ojhpjlocmbogdgmfpkhlaaeamibhnphh\",\"brand\":\"CHBF\",\"cohort\":\"1:w0x:\",\"cohortname\":\"All users\",\"enabled\":true,\""
		"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.545666a4efd056351597bb386aea1368105ededc976ed5650d8682daab9f37ff\"}]},\"ping\":{\"ping_freshness\":\"{5e46f82d-b901-4554-8f25-109d64d70328}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"3\"},{\"appid\":\"ggkkehgbnfjpeggfpleeakpidbkibbmn\",\"brand\":\"CHBF\",\"cohort\":\"1:ut9/1a0f/2c99:2c9f@0.5\",\"cohortname\":\"Rollout\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\""
		"1.d1f1a6954babb7330ef005df1b89dcdcb3d163ad1fed7a6800032ebb5d3b8b70\"}]},\"ping\":{\"ping_freshness\":\"{e44b5354-2f49-4bae-8cfa-ed45ad883073}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"2024.4.15.1148\"},{\"appid\":\"cocncanleafgejenidihemfflagifjic\",\"brand\":\"CHBF\",\"cohort\":\"1:13hr:\",\"cohortname\":\"Everyone Else\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.2b38451531e26ec7b046a0b16da068f362c78c09df795329402ccf77914c18b4\"}]},\""
		"ping\":{\"ping_freshness\":\"{7664073f-9d5b-4ce2-b9f8-cc2f01eb59ea}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"2023.3.30.1305\"},{\"appid\":\"jflhchccmppkfebkiaminageehmchikm\",\"brand\":\"CHBF\",\"cohort\":\"1:26yf:\",\"cohortname\":\"Stable\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.5b9f6915a4003e3615f4921e072f3f1b884167aa251a94e20928b3a1866e35eb\"}]},\"ping\":{\"ping_freshness\":\"{5cd9fbc8-1bd4-4670-87a4-85ffc0835104}\",\"rd\":6399},"
		"\"updatecheck\":{},\"version\":\"2024.7.7.1\"},{\"appid\":\"eeigpngbgcognadeebkilcpcaedhellh\",\"brand\":\"CHBF\",\"cohort\":\"1:w59:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.26c197ab0b2bd999fd5c8b5932e5700a083febf68e6d35f56b2473d6858a02cd\"}]},\"ping\":{\"ping_freshness\":\"{10218dcb-43cf-4992-9915-eaef29f32a82}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"2024.6.5.140657\"},{\"appid\":\""
		"gonpemdgkjcecdgbnaabipppbmgfggbe\",\"brand\":\"CHBF\",\"cohort\":\"1:z1x:\",\"cohortname\":\"Auto\",\"enabled\":true,\"installdate\":6390,\"lang\":\"en-US\",\"packages\":{\"package\":[{\"fp\":\"1.1848d9cb81709d6bb8a9612e1cba9fc97bb669c7ef81e2d11c0f937896df8e27\"}]},\"ping\":{\"ping_freshness\":\"{f9dadf62-5591-4057-b672-f2f973d615c3}\",\"rd\":6399},\"updatecheck\":{},\"version\":\"2024.6.26.0\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":16,\"sse"
		"\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"nacl_arch\":\"x86-64\",\"os\":{\"arch\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.20348.887\"},\"prodversion\":\"126.0.6478.127\",\"protocol\":\"3.1\",\"requestid\":\"{5274f5ff-1640-48e0-b882-4625cbc04421}\",\"sessionid\":\"{13274c90-f766-4f07-a84f-3193b7951121}\",\"updater\":{\"autoupdatecheckenabled\":true,\"ismachine\":true,\"lastchecked\":0,\"laststarted\":0,\"name\":\""
		"ChromiumUpdater\",\"updatepolicy\":-1,\"version\":\"128.0.6537.0\"},\"updaterversion\":\"126.0.6478.127\"}}", 
		LAST);
*/
	lr_think_time(9);

	lr_start_transaction("3_create_account");

	web_reg_find("Search=Body",
		"SaveCount=count3",
		"Text=User Registration",
		LAST);

	web_url("registration.php", 
		"URL=http://localhost/hospital/hms/registration.php", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost/hospital/hms/user-login.php", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://safebrowsing.googleapis.com/v4/threatListUpdates:fetch?$req="
		"Ch4KDGdvb2dsZWNocm9tZRIOMTI2LjAuNjQ3OC4xMjcaKQgFEAEaGwoNCAUQBhgBIgMwMDEwARCH6xcaAhgJKkjLfSIEIAEgAigBGikIARABGhsKDQgBEAYYASIDMDAxMAEQq9wOGgIYCTnyNAEiBCABIAIoARopCAMQARobCg0IAxAGGAEiAzAwMTABEMTTDhoCGAkhc5ImIgQgASACKAEaKQgOEAEaGwoNCA4QBhgBIgMwMDEwARD_xQcaAhgJl0Z5diIEIAEgAigBGigIARAIGhoKDQgBEAgYASIDMDAxMAQQ7zkaAhgJaetCbyIEIAEgAigEGikIDxABGhsKDQgPEAYYASIDMDAxMAEQ3psDGgIYCaCzMbkiBCABIAIoARonCAoQCBoZCg0IChAIGAEiAzAwMTABEAcaAhgJ6qKaVyIEIAEgAigBGicICRABGhkKDQgJEAYYASIDMDAxMAEQIxoCGAmL0zudIgQgASACKAEaKAgIEA"
		"EaGgoNCAgQBhgBIgMwMDEwARDKFhoCGAlVtLF2IgQgASACKAEaKQgNEAEaGwoNCA0QBhgBIgMwMDEwARCIowIaAhgJRkxVDCIEIAEgAigBGikIBxABGhsKDQgHEAYYASIDMDAxMAEQzaIPGgIYCZmIPz4iBCABIAIoARooCBAQARoaCg0IEBAGGAEiAzAwMTABEMklGgIYCQtC9ZsiBCABIAIoASICCAE=&$ct=application/x-protobuf&key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw", "Referer=", ENDITEM, 
		LAST);

	lr_think_time(21);

	web_submit_data("check_availability.php", 
		"Action=http://localhost/hospital/hms/check_availability.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/hospital/hms/registration.php", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=email", "Value=tester@gmail.com", ENDITEM, 
		LAST);

	lr_think_time(19);

	web_submit_data("registration.php_2", 
		"Action=http://localhost/hospital/hms/registration.php", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost/hospital/hms/registration.php", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		ITEMDATA, 
		"Name=full_name", "Value={p_name}", ENDITEM, 
		"Name=address", "Value={p_add}", ENDITEM, 
		"Name=city", "Value={p_city}", ENDITEM, 
		"Name=gender", "Value=female", ENDITEM, 
		"Name=email", "Value=tester@gmail.com", ENDITEM, 
		"Name=password", "Value={p_passwd}", ENDITEM, 
		"Name=password_again", "Value=admin@123", ENDITEM, 
		"Name=submit", "Value=", ENDITEM, 
		EXTRARES, 
		"Url=https://content-autofill.googleapis.com/v1/pages/ChVDaHJvbWUvMTI2LjAuNjQ3OC4xMjcSPAmMsO9R1YrVgRIFDZycPeMSBQ2U1FseEgUNRmcVfRIFDYOoWz0SBQ3OQUx6EgUN29zUxSGpvuAiYdf1_w==?alt=proto", "Referer=", ENDITEM, 
		LAST);
	
	if(atoi(lr_eval_string("{count3}"))==0)
	{
		lr_error_message("Text not found");
	}
	

	lr_end_transaction("3_create_account",LR_AUTO);

	lr_think_time(6);
	
	lr_output_message("%s",lr_eval_string("P_fullname: {p_name}, emain: {email}, date: {p_date_time}"));

	return 0;
}