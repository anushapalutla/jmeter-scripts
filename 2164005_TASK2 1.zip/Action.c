Action()
{

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Accept-Language", 
		"en-US,en;q=0.9");

	web_reg_find("Search=All",
		"SaveCount=count",
		"Text=JPetStore Demo",
		LAST);

	web_url("petstore.octoperf.com", 
		"URL=https://petstore.octoperf.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(11);
	
	if(atoi(lr_eval_string("{count}"))==0)

    {
        lr_error_message("Text not found");
    }
	
	web_reg_save_param("categoryId",
		"LB=categoryId=",
		"RB=\"><img src",
		"Ordinal=ALL",
		LAST);
	
	lr_start_transaction("LAUNCH");

	web_url("Enter the Store", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);
	
	lr_save_string(lr_paramarr_random("categoryId"),"P_RandomcategoryId");


	web_set_sockets_option("TLS_SNI", "0");

	lr_end_transaction("LAUNCH",LR_AUTO);

	lr_think_time(20);

	lr_start_transaction("SIGN_IN");

	web_url("Sign In", 
		"URL=https://petstore.octoperf.com/actions/Account.action;jsessionid=915C9D90F62F0BAF750EDA3265311B79?signonForm=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("Account.action", 
		"Action=https://petstore.octoperf.com/actions/Account.action", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Account.action;jsessionid=915C9D90F62F0BAF750EDA3265311B79?signonForm=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=username", "Value={P_NAME}", ENDITEM, 
		"Name=password", "Value={P_PASSWD}", ENDITEM, 
		"Name=signon", "Value=Login", ENDITEM, 
		"Name=_sourcePage", "Value=Jk4kpIOLY6tuklUUHPSKuqtPyc73iGccIiw0H1hyZmv7xmMKU17X0hsiuwyyuL0jv9lqMR_zoUv62ubCrm6KL7MRAiI43UzVTjpTm2NLuaE=", ENDITEM, 
		"Name=__fp", "Value=6jEuTDovbvGNw3mUZpFHS6dAFWtwqHDAWhJ6PBoJrUhl2HQJLZuwlm0RrOhRBygk", ENDITEM, 
		LAST);

	lr_end_transaction("SIGN_IN",LR_AUTO);

	lr_think_time(9);
	
	

	lr_start_transaction("CATEGORY");
	
	  web_reg_save_param_regexp(

        "ParamName=ProductID",
        "RegExp=viewProduct=&amp;productId=(.*?)\">",
        "Ordinal=ALL",
        SEARCH_FILTERS,
        LAST);


	/* web_reg_save_param("ProductID",
		"LB=productId=",
		"RB=\"",
		"ORD=ALL",
		LAST);
		*/
		
	web_reg_find("Search=All",
		"SaveCount=count1",
		"Text=Return to Main Menu",
		LAST);

	web_url("sm_{P_RandomcategoryId}.gif", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId={P_RandomcategoryId}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);
		
	if(atoi(lr_eval_string("{count1}"))==0)

    {
        lr_error_message("Text not found");
    }
		
	lr_save_string(lr_paramarr_random("ProductID"),"P_RandomProductId");

	lr_end_transaction("CATEGORY",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("PRODUCTS");

	web_url("{P_RandomProductId}", 
		"URL=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={P_RandomProductId}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewCategory=&categoryId={P_RandomcategoryId}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("PRODUCTS",LR_AUTO);

	lr_think_time(23);

	lr_start_transaction("ADD_TO_CART");

	web_url("Add to Cart", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-11", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Catalog.action?viewProduct=&productId={P_RandomProductId}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("ADD_TO_CART",LR_AUTO);

	lr_think_time(29);

	lr_start_transaction("VIEW_CART");

	web_url("cart.gif", 
		"URL=https://petstore.octoperf.com/actions/Cart.action?viewCart=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?addItemToCart=&workingItemId=EST-11", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("VIEW_CART",LR_AUTO);

	lr_start_transaction("LOGOUT");

	web_url("Sign Out", 
		"URL=https://petstore.octoperf.com/actions/Account.action?signoff=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://petstore.octoperf.com/actions/Cart.action?viewCart=", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("LOGOUT",LR_AUTO);

	return 0;
}